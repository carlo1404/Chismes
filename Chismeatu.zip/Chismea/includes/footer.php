<footer id="pie">
            <p>Desarrollado por {Nombre Aprendiz} &copy; <?php echo date("Y") ?></p>
        </footer>
        
    </body>
</html>