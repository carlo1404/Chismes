<?php require_once 'includes/header.php';?>
<?php require_once 'includes/barra.php';?>
    <div id="principal">
            <h1>Últimas entradas</h1>
            <div id="ver-todas">
                <a href="entradas.php">Ver todas las entradas</a>
            </div>
    </div>
<?php require_once 'includes/footer.php';?>